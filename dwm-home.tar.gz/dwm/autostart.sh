exec compton -b --vsync opengl-swc --paint-on-overlay &
exec slstatus &
exec nitrogen --restore &


sleep 5 && setxkbmap us && xmodmap ~/.Xmodmap
